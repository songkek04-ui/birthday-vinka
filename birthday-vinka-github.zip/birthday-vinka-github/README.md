# 💗 Birthday Vinka — GitHub Pages

Website ulang tahun full-screen untuk Vinka Maha Rani 🫀

## Struktur

```text
birthday-vinka/
├── index.html
├── images/
│   ├── foto1.jpg
│   ├── foto2.jpg
│   ├── foto3.jpg
│   └── foto4.jpg
└── music/
    └── lagu.mp3
```

## Cara memasukkan foto

1. Masukkan foto ke folder `images`.
2. Minimal siapkan:
   - `foto1.jpg`
   - `foto2.jpg`
3. Kalau ingin menambah foto, duplikat blok `.vb-polaroid` di `index.html`.

## Cara memasukkan lagu

1. Masukkan file MP3 ke folder `music`.
2. Misalnya namanya `lagu.mp3`.
3. Di `index.html`, cari:

```html
<audio id="vbMusic" loop preload="none" src=""></audio>
```

ubah menjadi:

```html
<audio id="vbMusic" loop preload="none" src="music/lagu.mp3"></audio>
```

Catatan: browser biasanya tidak mengizinkan musik otomatis berjalan sebelum pengguna melakukan interaksi. Tombol musik tersedia di pojok kanan atas.

## Cara publish dengan GitHub Pages

1. Buat repository baru di GitHub, misalnya `birthday-vinka`.
2. Upload `index.html`, folder `images`, dan folder `music`.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/ (root)`
5. Save.
6. Tunggu beberapa saat.
7. Link biasanya menjadi:

`https://USERNAME.github.io/birthday-vinka/`

Ganti `USERNAME` dengan username GitHub kamu.

## Catatan

Website ini sengaja dibuat full-screen dan tidak memakai layout Blogger.
